from fastapi import Depends

from app.core.config import settings
from app.routers.notification import router as notification_router
from app.routers.publish import router as publish_router
from shared.auth.deps import require_authenticated_user
from shared.config import parse_origins
from shared.openapi import create_service_app

app = create_service_app(
    service_id="notification-service",
    title="Notification Service",
    description="""
Queues an email notification and stores notifications for the signed-in user.

Delivery of email is currently a stub: the payload is logged and the response status is `queued`. `GET /notifications` returns only the caller's stored rows.
""",
    port=8006,
    cors_origins=parse_origins(settings.cors_origin),
    tags_metadata=[
        {
            "name": "notifications",
            "description": "Queue an outbound email notification.",
        }
    ],
)

app.include_router(notification_router, dependencies=[Depends(require_authenticated_user)])
# Called by other services with a service key, not a user token.
app.include_router(publish_router)
